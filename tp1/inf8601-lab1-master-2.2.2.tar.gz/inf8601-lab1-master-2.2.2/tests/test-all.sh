#!/bin/sh
${abs_top_srcdir}/src/dragonizer --cmd check --power 22 --thread 10


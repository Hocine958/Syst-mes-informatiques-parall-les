#!/bin/bash

source lib.sh

echo $PBS_O_WORKDIR

